/**
 * DEFINES IN THIS WILL ARE DEPRECATED AND WILL BE REMOVED IN A FUTURE SDK. PLEASE USE THE ERROR CODES FROM @code MAErrorCode.h @endcode instead!!!
 */

#define kMAErrorCodeNoFill 204
#define kMAErrorCodeUnspecifiedError -1
#define kMAErrorCodeInvalidInternalState -5201
#define kMAErrorCodeMediationAdapterLoadFailed -5001
#define kMAErrorCodeFullscreenAdAlreadyShowing -23
